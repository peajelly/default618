import argparse
import os
import mindspore.nn as nn
from mindspore import context
from mindspore.train.model import Model
from mindspore.train.serialization import load_checkpoint, load_param_into_net
from mindspore.common import set_seed
from mindspore import Tensor
from mindspore.common import dtype as mstype
from mindspore.nn.loss.loss import _Loss
from mindspore.ops import functional as F
from mindspore.ops import operations as P

from src.config import imagenet_cfg
from src.dataset import create_dataset_imagenet
import src.senet_ms as senets

set_seed(1)

def accprint(path):
        '''输出对应路径下的训练结果'''
        de_path = path
        param_dict = load_checkpoint(de_path)
        load_param_into_net(net, param_dict)
        net.set_train(False)
        acc = model.eval(dataset)
        print(f"model {de_path}'s accuracy is {acc}")

class CrossEntropySmooth(_Loss):
    """CrossEntropy"""
    def __init__(self, sparse=True, reduction='mean', smooth_factor=0., num_classes=1000):
        super(CrossEntropySmooth, self).__init__()
        self.onehot = P.OneHot()
        self.sparse = sparse
        self.on_value = Tensor(1.0 - smooth_factor, mstype.float32)
        self.off_value = Tensor(1.0 * smooth_factor / (num_classes - 1), mstype.float32)
        self.ce = nn.SoftmaxCrossEntropyWithLogits(reduction=reduction)

    def construct(self, logit, label):
        if self.sparse:
            label = self.onehot(label, F.shape(logit)[1], self.on_value, self.off_value)
        loss_ = self.ce(logit, label)
        return loss_


if __name__ == '__main__':


    cfg = imagenet_cfg
    if not cfg.use_label_smooth:
        cfg.label_smooth_factor = 0.0

    device_target = cfg.device_target
    context.set_context(mode=context.GRAPH_MODE, device_target=cfg.device_target)
    if device_target == "Ascend":
        context.set_context(device_id=cfg.device_id)

    dataset = create_dataset_imagenet(cfg.val_data_path, 1, False)
    loss = CrossEntropySmooth(sparse=True, reduction="mean",
                              smooth_factor=cfg.label_smooth_factor, num_classes=cfg.num_classes)
    net = senets.se_resnext50_32x4d(cfg.num_classes)
    model = Model(net, loss_fn=loss, metrics={'top_1_accuracy', 'top_5_accuracy'})
    '''file_list = os.listdir(cfg.checkpoint_path)
    for filename in file_list:
        de_path = os.path.join(cfg.checkpoint_path, filename)
        if de_path.endswith('.ckpt'):
            param_dict = load_checkpoint(de_path)
            load_param_into_net(net, param_dict)
            net.set_train(False)

            acc = model.eval(dataset)
            print(f"model {de_path}'s accuracy is {acc}")'''   ##输出所有训练的结果
    accprint('./ckpt/train_senet_imagenet-120_2694.ckpt')         ##输出最后5次训练结果
    '''accprint('./ckpt/train_senet_imagenet-118_2694.ckpt')  
    accprint('./ckpt/train_senet_imagenet-116_2694.ckpt')
    accprint('./ckpt/train_senet_imagenet-114_2694.ckpt')
    accprint('./ckpt/train_senet_imagenet-112_2694.ckpt')'''
