from easydict import EasyDict as edict

imagenet_cfg = edict({
    'name': 'imagenet',
    'pre_trained': False,
    'num_classes': 2388,
    'lr_init': 0.4,  # 8P: 0.4
    'batch_size': 128,
    'epoch_size': 120,
    'momentum': 0.9,
    'weight_decay': 1e-4,
    'image_height': 224,
    'image_width': 224,
    'data_path': '/media/zxm/新加卷/data2/RP2Krp2k_dataset(1)/all/train',
    'val_data_path':'/media/zxm/新加卷/data2/RP2Krp2k_dataset(1)/all/test',
    'device_target': 'Ascend',
    'device_id': 0,
    'keep_checkpoint_max': 80,
    'checkpoint_path': None,

    # optimizer and lr related
    'lr_scheduler': 'cosine_annealing',
    'lr_epochs': [30, 60, 90, 120],
    'lr_gamma': 0.1,
    'eta_min': 0.0,
    'T_max': 120,
    'warmup_epochs': 1,

    # loss related
    'is_dynamic_loss_scale': 0,
    'loss_scale': 1024,
    'label_smooth_factor': 0.1,
    'use_label_smooth': True,
})
